package ml.melun.mangaview.viewer

import android.content.Intent
import android.os.Debug
import android.os.SystemClock
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.UiDevice
import java.io.File
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import ml.melun.mangaview.ViewerApplication
import ml.melun.mangaview.activity.EngineTraversalGestureSpeed
import ml.melun.mangaview.activity.ViewerActivity
import ml.melun.mangaview.activity.injectEngineTraversalGesture
import ml.melun.mangaview.engine.work.WorkCoordinator
import ml.melun.mangaview.viewer.runtime.ViewerLaunchSpec
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Temporary probe: scroll three episodes for 300 gestures each and sample engine-frame cadence,
 * resident tiles, work ownership and memory after every batch to expose long-run degradation.
 */
@RunWith(AndroidJUnit4::class)
class LongSessionScrollProbeTest {
    @Test fun progressiveJankProbe() = runBlocking {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val context = instrumentation.targetContext
        val device = UiDevice.getInstance(instrumentation)
        val graph = (context.applicationContext as ViewerApplication).graph
        val coordinator = graph.engine.coordinator as? WorkCoordinator
        val output = File(context.getExternalFilesDir(null), "long-session-probe-${System.currentTimeMillis()}")
        check(output.mkdirs())
        val samples = StringBuilder()
        var gestures = 0
        for (episode in EPISODES) {
            val scenario = ActivityScenario.launch<ViewerActivity>(Intent(context, ViewerActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                putExtra(ViewerLaunchSpec.EXTRA_SOURCE_ID, "wfwf")
                putExtra(ViewerLaunchSpec.EXTRA_SERIES_KEY, "comic:10007")
                putExtra(ViewerLaunchSpec.EXTRA_EPISODE_KEY, episode)
            })
            var activity: ViewerActivity? = null
            scenario.onActivity { activity = it }
            val viewer = requireNotNull(activity)
            assertTrue("Episode $episode never became render-ready", waitForRendering(viewer, 30_000L))
            delay(1_500)
            // A stolen focus (dialog) silently swallows injected touches; prove delivery before measuring.
            assertTrue("Episode $episode never received injected input", verifyInputDelivery(viewer, scenario,
                instrumentation, device, output) { gestures++ })
            var frameCursor = 0L
            repeat(BATCHES_PER_EPISODE) { batch ->
                val forward = batch < BATCHES_PER_EPISODE / 2
                val batchStartedAt = SystemClock.elapsedRealtime()
                repeat(GESTURES_PER_BATCH) {
                    injectEngineTraversalGesture(instrumentation, device, output, gestures,
                        forward = forward, speed = EngineTraversalGestureSpeed.FAST)
                    gestures += 1
                }
                delay(SETTLE_MILLIS)
                val batchMillis = SystemClock.elapsedRealtime() - batchStartedAt
                val frameBatch = viewer.engineFramesSince(frameCursor)
                frameCursor = frameBatch.latestOrdinal
                val stamps = frameBatch.observations.map { observation ->
                    observation.presentation.timestampNanos.takeIf { it > 0L }
                        ?: observation.presentation.submittedAtNanos
                }
                val intervals = stamps.zipWithNext { a, b -> b - a }
                    .filter { it in 1..200_000_000L }
                    .sorted()
                val p50 = intervals.getOrNull(intervals.size / 2) ?: -1L
                val p95 = intervals.getOrNull((intervals.size * 95) / 100) ?: -1L
                val max = intervals.lastOrNull() ?: -1L
                val diagnostic = requireNotNull(viewer.viewerEngineDiagnosticSnapshot())
                val render = diagnostic.render
                val content = diagnostic.content
                var inputRevision = 0L
                scenario.onActivity { inputRevision = it.userInputRevisionSnapshot() }
                val heapUsedKb = (Runtime.getRuntime().let { it.totalMemory() - it.freeMemory() }) / 1024
                val line = "PROBE5 episode=$episode batch=$batch forward=$forward gestures=$gestures " +
                    "batchMillis=$batchMillis frames=${frameBatch.observations.size} " +
                    "framesLost=${frameBatch.lostCount} cadenceP50Ms=${p50 / 1_000_000.0} " +
                    "cadenceP95Ms=${p95 / 1_000_000.0} cadenceMaxMs=${max / 1_000_000.0} " +
                    "residentTiles=${render.residentTextureTiles.size} renderWork=${render.work} " +
                    "contentWork=${content.work} sessionPages=${content.runtime.pages.size} " +
                    "sessionPlans=${content.runtime.plans.size} inputRevision=$inputRevision " +
                    "heapUsedKb=$heapUsedKb nativeHeapKb=${Debug.getNativeHeapAllocatedSize() / 1024} " +
                    "pssKb=${Debug.getPss()}"
                android.util.Log.i("LongSessionProbe", line)
                samples.append(line).append('\n')
                coordinator?.let { android.util.Log.i("LongSessionProbe", "STUCK $episode/$batch ${it.debugStuckRecords()}") }
            }
            scenario.close()
            val closeCompleted = withTimeoutOrNull(90_000) { viewer.awaitEngineClosed() } != null
            delay(800)
            val ownership = graph.engine.coordinator.snapshot()
            val line = "PROBE5 episode=$episode CLOSED closeCompleted=$closeCompleted work=$ownership " +
                "nativeHeapKb=${Debug.getNativeHeapAllocatedSize() / 1024} pssKb=${Debug.getPss()} " +
                "stuck=${coordinator?.debugStuckRecords()}"
            android.util.Log.i("LongSessionProbe", line)
            samples.append(line).append('\n')
        }
        File(output, "samples.txt").writeText(samples.toString())
    }

    private suspend fun waitForRendering(viewer: ViewerActivity, timeoutMillis: Long): Boolean {
        val deadline = SystemClock.elapsedRealtime() + timeoutMillis
        while (SystemClock.elapsedRealtime() < deadline) {
            if (viewer.isViewerInputSurfaceReady() && viewer.viewerEngineFrameSnapshot() != null) return true
            delay(200)
        }
        return false
    }

    private suspend fun verifyInputDelivery(
        viewer: ViewerActivity,
        scenario: ActivityScenario<ViewerActivity>,
        instrumentation: android.app.Instrumentation,
        device: UiDevice,
        output: File,
        nextGesture: () -> Int,
    ): Boolean {
        repeat(6) { attempt ->
            val before = viewer.engineInputObservationsSince(0).latestOrdinal
            injectEngineTraversalGesture(instrumentation, device, output, nextGesture(),
                forward = attempt % 2 == 0, speed = EngineTraversalGestureSpeed.FAST)
            delay(700)
            if (viewer.engineInputObservationsSince(0).latestOrdinal > before) return true
        }
        return false
    }

    private companion object {
        val EPISODES = listOf("28", "27", "26")
        const val BATCHES_PER_EPISODE = 12
        const val GESTURES_PER_BATCH = 25
        const val SETTLE_MILLIS = 400L
    }
}
