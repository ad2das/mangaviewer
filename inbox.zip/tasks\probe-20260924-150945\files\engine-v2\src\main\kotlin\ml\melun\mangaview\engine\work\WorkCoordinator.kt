package ml.melun.mangaview.engine.work

import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.ContinuationInterceptor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import ml.melun.mangaview.engine.api.WorkCoordinatorPort
import ml.melun.mangaview.engine.api.WorkLease
import ml.melun.mangaview.engine.api.WorkLimits
import ml.melun.mangaview.engine.api.WorkOwnershipSnapshot
import ml.melun.mangaview.engine.api.WorkPriority
import ml.melun.mangaview.engine.api.WorkRequest
import ml.melun.mangaview.engine.api.WorkSubscription

class WorkCoordinator(
    scope: CoroutineScope,
    limits: WorkLimits = WorkLimits(),
    // The admission loop both admits every record and starts each worker on its own thread
    // (UNDISPATCHED), so it must not wait behind the very work it is admitting. On the shared
    // plumbing pool a saturated queue showed up as a tile's DEMAND->WORK_ENTER of 9.6ms against a
    // 0.7ms steady-state value, while the records themselves were only paying microseconds of real
    // bookkeeping. A caller may therefore supply a dedicated single-thread lane; ordering, permits
    // and the single-loop contract are unchanged.
    private val schedulerDispatcher: CoroutineDispatcher? = null,
) : WorkCoordinatorPort {
    internal val registry = WorkRegistry(limits)
    private val mutex get() = registry.mutex
    private val records get() = registry.records
    private val closeCompletion get() = registry.closeCompletion
    private val attemptTokens = AtomicLong()
    private val coordinatorJob = SupervisorJob(scope.coroutineContext[Job])
    internal val workerScope = CoroutineScope(scope.coroutineContext + coordinatorJob)
    private val cleanupJob = SupervisorJob()
    private val cleanupScope = CoroutineScope(scope.coroutineContext.minusKey(Job) + cleanupJob)
    private var closed: Boolean
        get() = registry.closed
        set(value) {
            registry.closed = value
        }
    private val execution = WorkExecution(this, registry, attemptTokens)
    private val orderedAdmission = WorkOrderedAdmission(this, registry, execution)
    private val schedulerJob: Job

    // A worker's first segment runs on the admitting thread when it is started UNDISPATCHED, which is
    // free only while that thread is one of several plumbing threads. On a dedicated single-thread
    // scheduler lane a blocking first segment stalls every other record: measured on the GPU AVD with
    // the dedicated lane, a read-ahead tile's page publish worst case went from 1.0ms to 40.6ms and
    // newxtoon d2r p50 to 15.8ms. The lane thread is the one resource admission cannot wait behind, so
    // only foreground records keep the undispatched start — that is what took the opening ntk
    // FOCUS/VISIBLE p50 from 33.3ms to 24.4ms (gate 28.75). Background records are dispatched, and
    // keying that on the record's domain instead measured worse still: the control records of a
    // background tile also run a little bookkeeping before they suspend, and with them on the lane
    // ntk FOCUS/VISIBLE p50 went 23.5ms -> 34.6ms and wfwf 7.6ms -> 8.1ms.
    internal fun startMode(priority: WorkPriority): CoroutineStart = when {
        schedulerDispatcher == null -> CoroutineStart.UNDISPATCHED
        !priority.background -> CoroutineStart.UNDISPATCHED
        else -> CoroutineStart.DEFAULT
    }

    init {
        schedulerJob = workerScope.launch(start = CoroutineStart.UNDISPATCHED) {
            val lane = schedulerDispatcher
            if (lane == null) orderedAdmission.schedulerLoop()
            else withContext(lane) { orderedAdmission.schedulerLoop() }
        }
        scope.coroutineContext[Job]?.invokeOnCompletion {
            cleanupScope.launch(start = CoroutineStart.UNDISPATCHED) {
                try {
                    withContext(NonCancellable) { close() }
                } catch (failure: Throwable) {
                    if (failure !is CancellationException || !closeCompletion.isCompleted) {
                        recordObserverFailure(failure)
                    }
                }
            }
        }
    }

    override suspend fun <T : Any> submit(request: WorkRequest<T>): WorkSubscription<T> =
        submitInternal(request)

    override suspend fun <T : Any> submitAfterRetirement(request: WorkRequest<T>): WorkSubscription<T> {
        while (true) {
            currentCoroutineContext().ensureActive()
            var retirement: CompletableDeferred<Unit>? = null
            val registered = mutex.withLock {
                checkOpenLocked()
                val previous = records[request.key]
                if (previous != null && (previous.state == WorkRecordState.RETIRING || previous.cancelRequested)) {
                    retirement = previous.completion
                    null
                } else registerLocked(request)
            }
            if (registered != null) {
                val (record, subscriber) = registered
                return CoordinatorSubscription(this, record, subscriber, request.key.resultType)
            }
            // This waiter owns neither a permit nor a subscription while prior cleanup runs.
            checkNotNull(retirement).await()
        }
    }

    override suspend fun <T : Any> acquire(request: WorkRequest<T>): WorkLease<T> {
        val subscription = submitInternal(request)
        val value = subscription.await()
        return subscription.lease(value)
    }

    private suspend fun <T : Any> submitInternal(request: WorkRequest<T>): CoordinatorSubscription<T> {
        val (record, subscriber) = mutex.withLock { registerLocked(request) }
        return CoordinatorSubscription(this, record, subscriber, request.key.resultType)
    }

    override suspend fun invalidate(principal: String, authEpoch: Long) {
        require(principal.isNotBlank() && authEpoch >= 0L)
        val (targets, actions) = mutex.withLock {
            val retired = maxOf(registry.retiredAuthEpochs[principal] ?: -1L, authEpoch)
            registry.retiredAuthEpochs[principal] = retired
            val selected = records.values.filter {
                it.key.principal == principal && it.authEpoch <= retired
            }
            selected to selected.map { execution.cancelRecordLocked(it) }
        }
        execution.applyCancelActions(actions)
        targets.forEach { it.completion.await() }
    }

    /** TEMP DIAGNOSTIC: stuck records are RUNNING/RETRY_WAIT with no subscribers; they never retire. */
    fun debugStuckRecords(): String = try {
        val all = records.values.toList()
        val stuck = all.filter {
            it.subscribers.isEmpty() && (it.state == WorkRecordState.RUNNING || it.state == WorkRecordState.RETRY_WAIT)
        }
        "total=${all.size} states=${all.groupingBy { it.state }.eachCount()} stuck=${stuck.size} " +
            stuck.joinToString(" | ") { record ->
                "${record.key.resource}|${record.key.operation}|rev=${record.key.contentRevision.take(20)}" +
                    "|cancel=${record.cancelRequested}|workerDone=${record.worker?.isCompleted}" +
                    "|deps=${record.dependencies.size}|waits=${record.retirementWaits.size}|attempt=${record.attempt}"
            }
    } catch (failure: Throwable) { "dump failed: $failure" }

    override suspend fun snapshot(): WorkOwnershipSnapshot = mutex.withLock {
        WorkOwnershipSnapshot(
            closed = closed,
            queued = records.values.count { it.state == WorkRecordState.QUEUED },
            active = records.values.count {
                it.state == WorkRecordState.RUNNING || it.state == WorkRecordState.RETRY_WAIT
            },
            retiring = records.values.count { it.state == WorkRecordState.RETIRING },
            subscribers = records.values.sumOf { it.subscribers.size },
            retainedResults = records.values.count { it.result != null },
        )
    }

    override suspend fun close() {
        val (first, actions) = mutex.withLock {
            if (closed) {
                false to emptyList<CancelActions>()
            } else {
                closed = true
                val cancellation = records.values.toList().map { execution.cancelRecordLocked(it) }
                if (records.isEmpty()) registry.completeCloseLocked()
                signalLocked()
                true to cancellation
            }
        }
        if (!first) {
            awaitCloseCompletion()
            return
        }
        schedulerJob.cancel()
        coordinatorJob.cancel()
        execution.applyCancelActions(actions)
        withContext(NonCancellable) {
            schedulerJob.join()
            try {
                awaitCloseCompletion()
            } finally {
                cleanupJob.cancel()
            }
        }
    }

    internal fun promote(record: WorkRecord, requested: WorkPriority) {
        if (record.priority.value.ordinal <= requested.ordinal) return
        if (mutex.tryLock()) {
            try {
                promoteLocked(record, requested)
            } finally {
                mutex.unlock()
            }
            return
        }
        cleanupScope.launch(start = CoroutineStart.UNDISPATCHED) {
            withContext(NonCancellable) {
                mutex.withLock { promoteLocked(record, requested) }
            }
        }
    }

    internal fun releaseAsync(record: WorkRecord, subscriber: WorkSubscriber) {
        cleanupScope.launch(start = CoroutineStart.UNDISPATCHED) {
            withContext(NonCancellable) {
                try {
                    release(record, subscriber)
                } catch (failure: Throwable) {
                    recordObserverFailure(failure)
                }
            }
        }
    }

    internal fun <T : Any> registerLocked(request: WorkRequest<T>): Pair<WorkRecord, WorkSubscriber> {
        checkOpenLocked()
        val retired = registry.retiredAuthEpochs[request.key.principal]
        if (retired != null && request.authEpoch <= retired) {
            throw WorkAuthEpochRetiredException(request.authEpoch)
        }
        val existing = records[request.key]
        if (existing != null) {
            if (existing.state == WorkRecordState.RETIRING || existing.cancelRequested) {
                throw WorkRetiringException(request.key)
            }
            validateCompatible(existing, request)
            promoteLocked(existing, request.priority)
            val subscriber = WorkSubscriber().also(existing.subscribers::add)
            if (existing.state == WorkRecordState.READY) {
                subscriber.ready.complete(checkNotNull(existing.result).value)
            }
            return existing to subscriber
        }
        val pending = records.values.count { it.state == WorkRecordState.QUEUED }
        if (pending >= registry.limits.queued) throw WorkQueueFullException(registry.limits.queued)
        val record = TypedWorkRecord(request, registry.sequence++)
        val subscriber = WorkSubscriber()
        record.subscribers += subscriber
        records[request.key] = record
        signalLocked()
        return record to subscriber
    }

    private fun <T : Any> validateCompatible(record: WorkRecord, request: WorkRequest<T>) {
        if (record.requestDomain != request.domain) {
            throw WorkRequestConflictException("Work key domain changed: ${request.key}")
        }
        if (record.authEpoch != request.authEpoch) {
            throw WorkRequestConflictException("Work key auth epoch changed: ${request.key}")
        }
    }

    internal suspend fun awaitSubscription(
        record: WorkRecord,
        subscriber: WorkSubscriber,
    ): Any {
        try {
            // A resumed mutex waiter owns the lock before its dispatcher runs it. Keep
            // that ownership off the UI queue, where a traversal can stall all work —
            // but keep the caller's Job: minusKey(Job) severed cancellation, so a
            // cancelled subscriber kept waiting and its detach/last-subscriber cleanup
            // never ran, wedging the record.
            val relocate = workerScope.coroutineContext[ContinuationInterceptor]
            if (relocate == null || relocate == currentCoroutineContext()[ContinuationInterceptor]) {
                return awaitReady(subscriber)
            }
            // An uncontended tryLock never suspends and never hands the lock to another
            // dispatcher, so when both checks come back free the whole wait — including the
            // completion resume — can stay on the caller's dispatcher. That is what keeps a
            // tile's residency callback one dispatch closer: measured on the GPU AVD, a
            // read-ahead tile's UPLOAD_DONE->RESIDENT gap was paying a plumbing round trip
            // plus the main queue before the result reached its owner.
            if (tryCheckLive(subscriber)) {
                val value = subscriber.ready.await()
                markDelivered(subscriber, relocate)
                return value
            }
            return withContext(relocate) { awaitReady(subscriber) }
        } catch (failure: Throwable) {
            withContext(NonCancellable) { detachAndAwait(record, subscriber) }
            throw failure
        }
    }

    /** True only when the liveness check ran without contending for the lock. */
    private fun tryCheckLive(subscriber: WorkSubscriber): Boolean {
        if (!mutex.tryLock()) return false
        try {
            checkSubscriptionLive(subscriber)
            return true
        } finally {
            mutex.unlock()
        }
    }

    private suspend fun markDelivered(subscriber: WorkSubscriber, relocate: ContinuationInterceptor) {
        if (mutex.tryLock()) {
            try {
                checkSubscriptionLive(subscriber)
                if (!subscriber.delivered) subscriber.delivered = true
            } finally {
                mutex.unlock()
            }
            return
        }
        // A resumed mutex waiter owns the lock before its dispatcher runs it, so a contended
        // acquisition still has to happen off the caller's dispatcher.
        withContext(relocate) {
            mutex.withLock {
                checkSubscriptionLive(subscriber)
                if (!subscriber.delivered) subscriber.delivered = true
            }
        }
    }

    private suspend fun awaitReady(subscriber: WorkSubscriber): Any {
        mutex.withLock {
            checkSubscriptionLive(subscriber)
        }
        val value = subscriber.ready.await()
        mutex.withLock {
            checkSubscriptionLive(subscriber)
            if (!subscriber.delivered) subscriber.delivered = true
        }
        return value
    }

    internal suspend fun detachAndAwait(record: WorkRecord, subscriber: WorkSubscriber) {
        detach(record, subscriber)
    }

    private suspend fun detach(record: WorkRecord, subscriber: WorkSubscriber) {
        val actions = mutex.withLock { detachLocked(record, subscriber) }
        actions.job?.cancel()
        actions.disposal?.let { execution.disposeRecord(it) }
        subscriber.releaseDone.await()
    }

    private suspend fun release(record: WorkRecord, subscriber: WorkSubscriber) {
        val actions = mutex.withLock { releaseLocked(record, subscriber) }
        actions.job?.cancel()
        actions.disposal?.let { execution.disposeRecord(it) }
        subscriber.releaseDone.await()
    }

    private fun detachLocked(record: WorkRecord, subscriber: WorkSubscriber): TransitionActions {
        if (subscriber.detached || subscriber.released) return TransitionActions()
        subscriber.detached = true
        subscriber.ready.cancel(CancellationException("Work subscription was closed"))
        if (records[record.key] !== record || record.state == WorkRecordState.DONE) {
            subscriber.releaseDone.complete(Unit)
            return TransitionActions()
        }
        record.subscribers.remove(subscriber)
        if (record.subscribers.isNotEmpty()) {
            subscriber.releaseDone.complete(Unit)
            signalLocked()
            return TransitionActions()
        }
        record.cleanupSubscribers += subscriber
        val actions = transitionLastSubscriberLocked(record)
        signalLocked()
        return actions
    }

    private fun releaseLocked(record: WorkRecord, subscriber: WorkSubscriber): TransitionActions {
        if (subscriber.released) return TransitionActions()
        if (subscriber.detached || !subscriber.delivered) return detachLocked(record, subscriber)
        subscriber.released = true
        if (records[record.key] !== record || record.state == WorkRecordState.DONE) {
            subscriber.releaseDone.complete(Unit)
            return TransitionActions()
        }
        record.subscribers.remove(subscriber)
        if (record.subscribers.isNotEmpty()) {
            subscriber.releaseDone.complete(Unit)
            signalLocked()
            return TransitionActions()
        }
        record.cleanupSubscribers += subscriber
        val actions = transitionLastSubscriberLocked(record)
        signalLocked()
        return actions
    }

    private fun transitionLastSubscriberLocked(record: WorkRecord): TransitionActions {
        return when (record.state) {
            WorkRecordState.QUEUED -> {
                execution.removeRecordLocked(record)
                TransitionActions()
            }
            WorkRecordState.RUNNING,
            WorkRecordState.RETRY_WAIT,
            -> {
                record.cancelRequested = true
                TransitionActions(job = record.worker)
            }
            WorkRecordState.READY ->
                TransitionActions(disposal = execution.planDisposalLocked(record))
            WorkRecordState.RETIRING,
            WorkRecordState.DONE,
            -> TransitionActions()
        }
    }

    private fun checkSubscriptionLive(subscriber: WorkSubscriber) {
        if (subscriber.detached || subscriber.released) {
            throw CancellationException("Work subscription is closed")
        }
    }

    internal fun promoteLocked(record: WorkRecord, requested: WorkPriority) {
        if (closed || records[record.key] !== record || record.state == WorkRecordState.RETIRING ||
            record.cancelRequested
        ) return
        if (requested.ordinal < record.priority.value.ordinal) {
            record.priority.value = requested
            record.dependencies.values.forEach { promoteLocked(it, requested) }
            signalLocked()
        }
    }

    private fun checkOpenLocked() {
        if (closed || !coordinatorJob.isActive) throw WorkCoordinatorClosedException()
    }

    private fun signalLocked() {
        registry.signalLocked()
    }

    private suspend fun awaitCloseCompletion() {
        closeCompletion.await()
        val failure = mutex.withLock { registry.disposalFailure }
        failure?.let { throw it }
    }

    private suspend fun recordObserverFailure(failure: Throwable) {
        withContext(NonCancellable) {
            mutex.withLock {
                registry.registerDisposalFailureLocked(failure)
                if (closed && records.isEmpty()) registry.completeCloseLocked()
            }
        }
    }

    private data class TransitionActions(
        val job: Job? = null,
        val disposal: DisposalPlan? = null,
    )
}
