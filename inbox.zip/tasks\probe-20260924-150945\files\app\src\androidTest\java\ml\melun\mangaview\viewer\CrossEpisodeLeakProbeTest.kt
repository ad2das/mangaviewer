package ml.melun.mangaview.viewer

import android.content.Intent
import android.os.Debug
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.UiDevice
import java.io.File
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import ml.melun.mangaview.ViewerApplication
import ml.melun.mangaview.activity.EngineTraversalGestureSpeed
import ml.melun.mangaview.activity.ViewerActivity
import ml.melun.mangaview.activity.injectEngineTraversalGesture
import ml.melun.mangaview.viewer.runtime.ViewerLaunchSpec
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Temporary probe: open and close several episodes and sample the app-scoped work registry plus
 * process memory after each close. Anything that grows per episode is a cross-session leak.
 */
@RunWith(AndroidJUnit4::class)
class CrossEpisodeLeakProbeTest {
    @Test fun appScopedWorkDoesNotGrowPerEpisode() = runBlocking {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val context = instrumentation.targetContext
        val device = UiDevice.getInstance(instrumentation)
        val graph = (context.applicationContext as ViewerApplication).graph
        val output = File(context.getExternalFilesDir(null), "cross-episode-probe-${System.currentTimeMillis()}")
        check(output.mkdirs())
        val samples = StringBuilder()
        var gestures = 0
        for (episode in EPISODES) {
            val scenario = ActivityScenario.launch<ViewerActivity>(Intent(context, ViewerActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                putExtra(ViewerLaunchSpec.EXTRA_SOURCE_ID, "wfwf")
                putExtra(ViewerLaunchSpec.EXTRA_SERIES_KEY, "comic:10007")
                putExtra(ViewerLaunchSpec.EXTRA_EPISODE_KEY, episode)
            })
            var activity: ViewerActivity? = null
            scenario.onActivity { activity = it }
            val viewer = requireNotNull(activity)
            assertTrue("Episode $episode never showed a surface", ViewerUiConditions.waitForSurface(device, 20_000L))
            delay(1_200)
            repeat(8) {
                injectEngineTraversalGesture(instrumentation, device, output, gestures,
                    forward = true, speed = EngineTraversalGestureSpeed.FAST)
                gestures += 1
            }
            delay(600)
            scenario.close()
            withTimeout(30_000) { viewer.awaitEngineClosed() }
            delay(800)
            val ownership = graph.engine.coordinator.snapshot()
            val heapUsedKb = (Runtime.getRuntime().let { it.totalMemory() - it.freeMemory() }) / 1024
            val line = "XPROBE episode=$episode work=$ownership heapUsedKb=$heapUsedKb " +
                "nativeHeapKb=${Debug.getNativeHeapAllocatedSize() / 1024} pssKb=${Debug.getPss()}"
            android.util.Log.i("CrossEpisodeProbe", line)
            samples.append(line).append('\n')
        }
        File(output, "samples.txt").writeText(samples.toString())
    }

    private companion object {
        val EPISODES = listOf("28", "27", "26", "25", "24", "23", "22", "21")
    }
}
